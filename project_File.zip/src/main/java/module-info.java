module org.example.moneyapplication {
    requires javafx.controls;
    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires java.desktop;
    requires java.sql;
    requires org.apache.logging.log4j;
    exports org.example.moneyapplication;
}