package org.example.moneyapplication;

public class Main {

    public static void main(final String[] args) {
        cashApplication.launch(cashApplication.class, args);
    }
}
